const cart = Cart.getCartObject();
cart.render();